<?php

namespace App\Controllers;

use App\Di\Container;

trait Crud {

    
    public function delete($id)
     {
        $stmt = $this->db->prepare("delete from ".$this->getTable()." where id=:id");
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        return true;
    }

    
    public function fetchAll()
     {
        
        $model = Container::getClass($this->model);                   
        return $model->fetchAllIncidentes();
    }

    

    

  
    

    

}
