<?php

namespace App\Controllers;

use App\Di\Container;

/*
{
	"id":"1",
	"atendente": "4", 
	"cliente":"1",
	"descricao":"teste api",
	"status":"aberto"
}
*/

// extendemos o model com a  action que faz o tratamento das rotas
class Incidentes extends Action
{
   
    protected $model = "incidentes";
     
    use Crud;
    
    
    //GET
    public function index()
    {    
        //retornamos os dados dos incidentes             
        $incidentes = $this->fetchAll();

        //convertemos o resulado em json
        Incidentes::formattedDataJson($incidentes);
    }                       
       

    //POST
    public function create()
    {    
        //pegamos os dados da requisição
        $request = Incidentes::getRequest();
       
        // carregamos o model com o object(PDO) já incatnciado
        $model = Container::getClass($this->model);
       
        // enviamos os dados da requisição para  salvar através do model
        $data = $model->save($request);
        
        // verificamos se o insert foi verdadeiro ou falso
        if($data['succes'] == 'false')
        {
        // retornamos mensagem de erro
           echo $data['message'];
            
        } else{

        // retornamos o objeto salvo
            Incidentes::formattedDataJson($data['message']);
        }      
        
    }

    //GET by Id
    public function show()
     {           
       // carregamos o model       
        $model = Container::getClass($this->model); 

      // enviamos os id requisição para  fazer o select através do model       
        $data = $model->findIncidente($_GET['id']); 

      // verificamos se a consulta foi verdadeiro ou falso
        if($data['succes'] == 'false')
        {
      // retornamos mensagem de erro
        echo $data['message'];
            
        } else
        {
      // retornamos o objeto salvo
          Incidentes::formattedDataJson($data['message']);
        }       
    }

    //PUT
    public function edit()
    {  
      //pegamos os dados da requisição  
        $request = Incidentes::getRequest();

       // carregamos o model com o object(PDO) já incatnciado
        $model = Container::getClass($this->model);

      // enviamos os dados da requisição para  update através do model
        $data = $model->save($request);

      // verificamos se a consulta foi verdadeiro ou falso
        if($data['succes'] == 'false')
        {
      // retornamos mensagem de erro
           echo $data['message'];
            
        } else{
      // retornamos o objeto atuzalido
            Incidentes::formattedDataJson($data['message']);
        }
               
    }

    // função para pegar os dados da requisição
    public function getRequest()
    {
        $json = file_get_contents('php://input');
      
        if(!empty($json))
        {
            return $obj = json_decode($json, TRUE);

        } else{
            $message = ['error' => 'verifique os campos !!'];
            $json_str = json_encode(['data' => $message],true);
            echo $json_str;  
        }
        exit();
        
    }

   // função para converter os objetos em json
    public function formattedDataJson(array $data)
    {
       
        foreach ($data as  $res )
        {        
            $params['id']               = $res['id'];        
            $params['atendente_nome']   = $res['atendente_nome'];
            $params['cliente_nome']     = $res['cliente_nome'];
            $params['descricao']        = $res['descricao'];
            $params['status']           = $res['status'];
            $params['creation_time']    = $res['creation_time'];
            
            $dataIncidente[] = $params;          
                
        }

        $json_str = json_encode(['data' => $dataIncidente],true);            
        echo $json_str;
    }
 
}
