<?php

namespace App\Di;


// container de injeção de dependencia para evitar o auto acoplamento ao instanciar 
class Container {

   
    // conexão PDO com banco de dados
    private static function getDb() {
        $db = new \PDO("mysql:host=localhost;dbname=teste_chall", "root", "ab45", array(\PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
        $db->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        return $db;
    }

   //montamos o model com a conexao instanciada
    public static function getClass($name, $data = "") {        
        $str_class = "\\App\\Models\\" . ucfirst($name);
        if ($data)
            $class = new $str_class(self::getDb(), $data);
        else
            $class = new $str_class(self::getDb());
        return $class;
    }
}
