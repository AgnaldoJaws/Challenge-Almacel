<?php

namespace App\Models;

use App\Db\Table;


class Incidentes extends Table {

   
    protected $table = "incidentes";

   // função de insert
    protected function _insert(array $data)
     {    
                
        if (!empty($data))
        {            
            $stmt = $this->db->prepare(
                "INSERT INTO ".$this->getTable().
                "(atendente, cliente, descricao, status, creation_time) VALUES(:atendente, :cliente, :descricao, :status, :creation_time)"
            );
           
            $stmt->bindParam(":atendente", $data['atendente']);
            $stmt->bindParam(":cliente", $data['cliente']);
            $stmt->bindParam(":descricao", $data['descricao']);
            $stmt->bindParam(":status", $data['status']);      
            $dt = new \DateTime();
            $agora =$dt->format('Y-m-d H:i:s');
            $stmt->bindParam(":creation_time",$agora); 
            $stmt->execute();          
            $id = $this->db->lastInsertId();
                     
            $data  = Incidentes::findIncidente($id);
            return $data;
            
        }
            else 
            {
                return  $message = ['succes' => 'false', 'message' => 'resurce not found'];
            }
    
       
    }

    // função de update
    protected function _update(array $data) 
    {    
       
        $incidente = Incidentes::findIncidente($data['id']);
        
        
        if (!empty($incidente))
        {
            $query = "UPDATE ".$this->getTable()." set descricao=:descricao, status=:status WHERE id=:id";
            $stmt = $this->db->prepare($query);
            $stmt->bindValue(":descricao",$data['descricao']);
            $stmt->bindValue(":status",$data['status']);
            $stmt->bindValue(":id",$data['id']);       
            $ret = $stmt->execute();
            $data = Incidentes::findIncidente($data['id']);

            return $data;
            
            } else 
            {
                return  $message = ['succes' => 'false', 'message' => 'resurce not found'];
                        
            }
       }

    // função para retornas todos os incidentes
    public function fetchAllIncidentes()
     {
        $query = "select i.id , a.nome AS atendente_nome, c.nome AS cliente_nome, i.descricao, i.status, i.creation_time from incidentes  i 
        inner join  clientes c on c.id = i.cliente
        inner join  atendentes a on a.id = i.atendente;";
        $stmt = $this->db->prepare($query);
        $stmt->execute();       
        return $stmt->fetchAll();
    }

    // função para pegar um núnico incidente
    public function findIncidente($id) 
    {      
       
        if ($id != null)
        {
            $query = "select i.id , a.nome AS atendente_nome, c.nome AS cliente_nome, i.descricao, i.status, i.creation_time from incidentes  i 
            inner join  clientes c on c.id = i.cliente
            inner join  atendentes a on a.id = i.atendente WHERE i.id=:id;";
            $stmt = $this->db->prepare($query);
            $stmt->bindValue(":id",$id); 
            $stmt->execute();       
            $data = $stmt->fetchAll();           

            return $message = ['succes' => 'true', 'message' => $data];

        } else{
            
            return  $message = ['succes' => 'false', 'message' => 'resurce not found'];
        }
        
        
        
    }
    


}