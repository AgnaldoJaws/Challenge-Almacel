<?php

namespace App;

use App\Init\Bootstrap;

/**
 * Class Init
 * @package App
 */
class Init extends Bootstrap
{

    /**
     * Método para setar rotas, baseadas em controlers e actions
     */
    protected function initRoutes()
    {
        $ar['home'] = ['route' => '/api/incidentes/get', 'controller' => 'incidentes', 'action' => 'index'];
      
        $ar['incidentes-novo'] = ['route' => '/api/incidentes/create', 'controller' => 'incidentes', 'action' => 'create'];

        $ar['incidentes-show'] = ['route' => '/api/incidentes/getBy', 'controller' => 'incidentes', 'action' => 'show'];

        $ar['incidentes-edit'] = ['route' => '/api/incidentes/update', 'controller' => 'incidentes', 'action' => 'edit'];

        $ar['incidentes-detele'] = ['route' => '/api/incidentes/delete', 'controller' => 'incidentes', 'action' => 'delete'];
       
        
        $this->setRoutes($ar);
    }



}
