<?php

ini_set('display_errors', true);
require_once '../vendor/autoload.php';

$bootstrap = new App\Init();
